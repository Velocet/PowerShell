# this needs to run from an administrator account
# on vista, you'd need to run powershell.exe as admin (right click on shortcut, etc)
installutil "grrr-snapin\bin\Release\Soapyfrog.Grrr.dll"

add-pssnapin Soapyfrog.Grrr  



